earth.mp4 is a public domain video that can be found in the NASA Scientific Visualization Studio.

https://svs.gsfc.nasa.gov/30082

Full Credits:
NASA Earth Observatory image by Robert Simmon, using Suomi NPP VIIRS data provided courtesy of Chris Elvidge (NOAA National Geophysical Data Center). Suomi NPP is the result of a partnership between NASA, NOAA, and the Department of Defense.

Animator: Robert Simmon (Sigma Space Corporation) [Lead]
Writer: Heather Hanson (GST) 
Project support: Eric Sokolowsky (GST) 

Further NASA SVS copyright and credit information can be found here:
https://svs.gsfc.nasa.gov/help/#copyrights-and-credits
